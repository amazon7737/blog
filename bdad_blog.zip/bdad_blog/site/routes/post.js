var express = require("express");
var router = express.Router();
const pool = require("../db/db");
/* GET home page. */
router.get("/", async (req, res, next) => {
  res.render("post", { title: "Node.js" });
});

router.get("/create", async (req, res, next) => {
  res.render("post");
});

router.post("/create", async (req, res, next) => {
  const { posttitle, postvalue } = req.body;
  const uid = "kkk";
  // const now = new date();
  let today = new Date();
  let year = today.getFullYear();
  let month = today.getMonth() + 1;
  let date = today.getDate();
  const wdate = year + "-" + month + "-" + date;
  const createPost = await pool.query(
    "INSERT INTO post values(null, ?, ?, ?, ?, null)",
    [posttitle, postvalue, wdate, uid]
  );

  res.redirect("/");
});
// /post -> postrouter
// /add -> postrouter -> add

// ejs 폼만들기 서브밋 버튼 만들기 라우터 받을 준비 라우터 디비로 보내기
// 지우기 : 목록을 받아와서 그중에서 삭제할 항목을 고른다 삭제 요청을 디비로 보낸다.
// router.post('/add', async (req, res, next) => {

//     const {posttitle, postvalue} = req.body; // 받아노느 데이터 req res는 보내는 데이터
//     const add_post = await pool.query(
//         "insert into post values(null, ?, ?);",
//        [ posttitle,
//         postvalue]);

//     // async
//     // await 기다린다 작업할떄까지

//     //    console.log(posttitle, postvalue);

//     res.render('post', { title: 'Node.js'} );
//   });

// router.get('/del', async (req, res, next) => {
//   const post = await pool.query("select * from post");
//   console.log(post[0]);
//   res.render('postdel', { title: 'Node.js', post: post[0] } );
// });

// router.get('/del/:target', async (req, res, next) => {

//   const target = req.params.target;
//   const delpost = await pool.query("delete from post where id = ?", [
//       target,
//   ]);
//   // console.log(post[0]);
//   res.redirect("/post/del");

//   });

//   router.get('/update', async (req, res, next) => {
//       const post = await pool.query("select * from post");
//       res.render('postupdate', { title: 'Node.js', post: post[0] } );
//       });

//   router.post('/update', async (req, res, next) => {
//       const {posttitle, postvalue} = req.body;
//       const update_post = await pool.query("update post set title = ?, value = ? where id = 100;", [posttitle, postvalue]);
//       res.render('postupdate', { title: 'Node.js'} );
//       });

module.exports = router;
