var express = require("express");
var router = express.Router();
const pool = require("../db/db");
/* GET home page. */
router.get("/", async (req, res, next) => {
  const posts = await pool.query("SELECT * FROM post;");
  console.log(posts[0]); // 데이터베이스에서 인증값이라 그런것들이 같이 와서 0번을 많이 붙여서 보내본다.
  // 찾는다 SELECT , 모든것을 가져온다 SELECT * , from (어디서) 변수는 소문자, 명령어는 대문자로 구분해서 편하게..
  res.render("index", { title: "Node.js", posts: posts[0] }); // 딕셔너리처럼 key , value 똑같은 구조
});

module.exports = router;
// 웹사이트에서 새로고침해야 불러와짐
