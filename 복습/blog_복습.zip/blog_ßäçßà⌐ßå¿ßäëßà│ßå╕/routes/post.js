var express = require("express");
var router = express.Router();
const pool = require("../db/db");

router.get("/", async (req, res, next) => {
  const post = await pool.query("SELECT * from post");

  res.render("post", { title: "Node.js" });
});

router.post("/", async (req, res, next) => {
  res.render("post");
});

router.get("create", async (req, res, next) => {
  res.render("post");
});

router.post("/create", async (req, res, next) => {
  const { posttitle, postvalue } = req.body;
  const uid = "kkk"; // 작성자 pwriter
  // const now = new date();
  let today = new Date();
  let year = today.getFullYear();
  let month = today.getMonth() + 1;
  let date = today.getDate();
  const wdate = year + "-" + month + "-" + date;
  const createPost = await pool.query(
    "INSERT INTO post values(null, ?, ?, ?, ?, null)",
    [posttitle, postvalue, wdate, uid]
  );
  // console.log([posttitle, postvalue, wdate, uid]);

  res.redirect("/");
});

router.get("/del", async (req, res, next) => {
  console.log(post[0]);
  res.render("postdel", { title: "Node.js", post: post[0] });
});

router.get("/del/:target", async (req, res, next) => {
  const target = req.params.target;
  const delpost = await pool.query("DELETE from post where pid = ?", [target]);

  res.redirect("/");
});

router.get("/del", async (req, res, next) => {
  const post = await pool.query("SELECT * FROM post");
  console.log(post[0]);
  res.render("postdel", { title: "Node.js", post: post[0] });
});

// router.get("/del/:target", async (req, res, next) => {
//   const target = req.params.target;
//   const delpost = await pool.query("DELETE FROM post where pid = ?", [target]);
//   console.log(post[0]);
//   res.redirect("/post/del");
// });

router.post("/updatepage", async (req, res, next) => {
  const post = await pool.query("SELECT * FROM post");
  console.log(post[0]);
  console.log(req.body.pid);
  res.render("postupdate", { title: "blog", post: post[0], pid: req.body.pid });
});

router.post("/update", async (req, res, next) => {
  var pid = req.body.pid;
  var ptitle = req.body.posttitle;
  var pvalue = req.body.postvalue;
  console.log(pid);
  // const { posttitle, postvalue } = req.body;
  // const { pid } = req.id;

  const update_post = await pool.query(
    "UPDATE post set ptitle = ?, pvalue=? where pid=? ;",
    [ptitle, pvalue, pid]
  );
  // post[0][1].pid 앞에 post 정의 해서 await 걸어주면 데이터 가져온다.
  // console.log([pid]);
  // res.send(req.id);
  res.redirect("/");
});

module.exports = router;
